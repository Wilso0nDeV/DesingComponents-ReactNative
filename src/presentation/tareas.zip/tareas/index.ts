export * from './Tarea1';
export * from './Tarea2';
export * from './Tarea3';
export * from './Tarea4';
export * from './Tarea5';

